<template recyclable="true">
  <div class="footer">
    <text class="copyright">All rights reserved.</text>
  </div>
</template>

<style scoped>
  .footer {
    height: 80px;
    justify-content: center;
    background-color: #EEEEEE;
  }
  .copyright {
    color: #AAAAAA;
    font-size: 32px;
    text-align: center;
  }
</style>
